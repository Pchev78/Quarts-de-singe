#include "jouer.h"

/**
 * @brief Demande � l'utilisateur de saisir une lettre pour compl�ter le mot.
 * Si le caract�re '!' est saisi, le joueur abandonne la manche.
 * Si le caract�re '?' est saisi, le joueur pr�c�dent est invit� � dire � quel mot il pensait lorsqu'il a jou�.
 * @param [in,out] mot_a_completer : mot que l'utilisateur doit compl�ter.
 * @param [in] joueur_courant : joueur qui joue actuellement.
 */
void humain(char* mot_a_completer, unsigned int longueur_mot, ConteneurTDE* conteneur_joueurs, Joueur* joueur_courant, bool* fin_manche) {
	char lettre;
	cin >> lettre;
	cin.ignore(MAX_LETTRES, '\n');
	lettre = toupper(lettre);
	if (lettre == '!') {
		cout << "le joueur " << joueur_courant->pos + 1 << joueur_courant->nature<< " abandonne la manche et prend un quart de singe" << endl;
		joueur_courant->qds += 0.25;
		*fin_manche = true;
		return;
	} else if (lettre == '?') {
		demander_mot_joueur_precedent(conteneur_joueurs, *joueur_courant);
		*fin_manche = true;
		return;
	}
	mot_a_completer[longueur_mot] = lettre;
	return;
}