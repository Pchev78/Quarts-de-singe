#include "comparaison.h"
#include "jouer.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;


void afficher(std::ostream& os, const char* mot){
	os << mot << endl;
}

/**
 * @brief Prend un mot du dictionnaire et le copie dans la variable mot.
 * @param [in,out] mot : mot qui va �tre copi� � partir du dictionnaire.
 * @param [in] is : dictionnaire.
 */
void saisir_mot_dictionnaire(std::istream& is, char* mot) {
    char tmp[MAX_LETTRES];
    is >> setw(MAX_LETTRES) >> tmp;
	for (int lettre = 0; lettre < strlen(tmp); lettre++) {
		mot[lettre] = tmp[lettre];
	}
}

/**
 * @brief Compare les mots du dictionnaire avec celui donn� en param�tre.
 * @param [in] mot : mot que l'utilisateur a voulu comparer.
 * @return true si le mot existe dans le dictionnaire.
 * @return false si le mot n'existe pas dans le dictionnaire.
 */

bool mot_existe_dans_dictionnaire(char mot[MAX_LETTRES]) 
{
	ifstream dictionnaire("ods4.txt");
	if (!dictionnaire) {
		cerr << "Probleme lors de l'ouverture du fichier.";
		return false;
	}
	for (int lettre = 0; lettre < strlen(mot); lettre++) {
		mot[lettre] = toupper(mot[lettre]);
	}
	char mot_dictionnaire[MAX_LETTRES];
	while (dictionnaire.getline(mot_dictionnaire, sizeof(mot_dictionnaire)))
	{
		if (strcmp(mot_dictionnaire, mot) == 0) {
			return true;
		}
	}
	return false;
}

unsigned int nb_mots_dictionnaire() {
	ifstream dictionnaire("ods4.txt");
	if (!dictionnaire) {
		cerr << "Probleme lors de l'ouverture du fichier." << endl;
		return 0;
	}
	char mot_dictionnaire[MAX_LETTRES];
	unsigned int nb_mots = 0;
	while (dictionnaire.getline(mot_dictionnaire, sizeof(dictionnaire))) {
		nb_mots++;
	}
	return nb_mots;
}


char** mot_coherent(char* debut_mot, unsigned int longueur_debut_mot, unsigned int* nb_mots_coherents, unsigned int nb_mots_dictionnaire) {
	const unsigned int MAX_MOTS = nb_mots_dictionnaire;
	char** mots_coherents = new char* [MAX_MOTS];
	ifstream dictionnaire("ods4.txt");
	char ligne[MAX_LETTRES];
	*nb_mots_coherents = 0;
	while (dictionnaire.getline(ligne, MAX_MOTS)) {
		ligne[strlen(ligne) - 1] = '\0';
		if (strncmp(ligne, debut_mot, longueur_debut_mot) == 0) {
			if (*nb_mots_coherents < MAX_MOTS) {
				mots_coherents[*nb_mots_coherents] = new char[MAX_LETTRES];
				strcpy(mots_coherents[*nb_mots_coherents], ligne);
				(*nb_mots_coherents)++;
			}
		}
	}
	dictionnaire.close();
	return mots_coherents;
}

/*
//Fonction de Gobigan SANS MALLOC
char** getMatchingWords(char* prefix, int prefixLength, int* numMatchingWords) {
	const int MAX_MATCHING_WORDS = MAX_LIGNES; // MAX_LIGNES = nombre de mots dans le document
	char** matchingWords = new char* [MAX_MATCHING_WORDS];
	*numMatchingWords = 0;

	ifstream dictionary("ods4.txt");
	char line[MAX_lettre];

	while (dictionary.getline(line, MAX_lettre)) {
		line[strlen(line) - 1] = '\0';
		if (strncmp(line, prefix, prefixLength) == 0) {
			if (*numMatchingWords < MAX_MATCHING_WORDS) {
				matchingWords[*numMatchingWords] = new char[MAX_lettre];
				strcpy(matchingWords[*numMatchingWords], line);
				(*numMatchingWords)++;
			}
		}
	}
	dictionary.close();
	return matchingWords;
}
//*/