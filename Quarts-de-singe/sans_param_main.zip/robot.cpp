#include "jouer.h"


char lettre_aleatoire() {
	char ch = 'A' + rand() % LONGUEUR_ALPHABET; // On prend A et on lui ajoute un nombre al�atoire entre 0 (correspondant � A) et LONGUEUR_ALPHABET (correspondant � Z)
	return ch;
}

char lettre_coherente(char* mot, unsigned int longueur_mot, ConteneurTDE* conteneur_joueurs, Joueur* joueur_courant, bool* fin_manche) {
	unsigned int nb_mots_coherents = 0, nb_mots_dico = nb_mots_dictionnaire();
	char** mots_coherents = mot_coherent(mot, longueur_mot, &nb_mots_coherents, nb_mots_dico);
	if (nb_mots_coherents == 0) {
		cout << '?';
		demander_mot_joueur_precedent(conteneur_joueurs, *joueur_courant);
		*fin_manche = true;
	}
	else {
		unsigned int nb_aleatoire = rand() % nb_mots_coherents;
		char* mot_choisi = mots_coherents[nb_aleatoire];
		return mot_choisi[longueur_mot];
	}
	return '!';
}

void robot(char* mot_a_completer, unsigned int longueur_mot, ConteneurTDE* conteneur_joueurs, Joueur* joueur_courant, bool* fin_manche) {
	srand(time(NULL));
	if (longueur_mot  == 0) { // Si le robot doit saisir la premi�re lettre du mot
		mot_a_completer[longueur_mot] = lettre_aleatoire();
	}
	else {
		mot_a_completer[longueur_mot] = lettre_coherente(mot_a_completer, longueur_mot, conteneur_joueurs, joueur_courant, fin_manche);
	}
	cout << "mot : " << mot_a_completer << endl;
}
