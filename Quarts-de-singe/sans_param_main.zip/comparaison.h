#ifndef comparaison
#define comparaison
#pragma once

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

enum {
	MIN_LETTRES = 2,			// Nombre minimal de lettres pour un mot dans le dictionnaire
	MAX_LETTRES = 26			// Nombre maximal de lettres pour un mot dans le dictionnaire
};

void afficher(std::ostream& os, const char* mot);

void saisir_mot_dictionnaire(std::istream& is, char* mot);

bool mot_existe_dans_dictionnaire(char mot[MAX_LETTRES]);

unsigned int nb_mots_dictionnaire();

char** mot_coherent(char* debut_mot, unsigned int longueur_debut_mot, unsigned int* nb_mots_coherents, unsigned int nb_mots_dictionnaire);

#endif