#include <iostream>
#include <stdio.h>
#pragma warning disable 4996
#include "comparaison.h"
#include "jouer.h"



int main(int nb_joueurs, char* joueurs[]) {
	if (nb_joueurs < MIN_JOUEURS) {
		cerr << "Pas assez de joueurs" << endl;
	}
	else if (nb_joueurs > MAX_LETTRES) {
		cerr << "Trop de joueurs" << endl;
	}
	lancer_jeu(*joueurs);
	/*
	char mot[MAX_LETTRES];
	mot[0] = 'D';
	mot[1] = 'E';
	bool existe = mot_existe_dans_dictionnaire(mot);
	cout << existe;
	*/
}
/*
int main(int argc, const char* argv[]) {
	// parametre sur la ligne de commande
	if (argc >= 2)
		cout << "le 1er parametre est '" << argv[1] << "'" << endl;
	else
		cout << "il n'y a pas de parametre" << endl;
}
*/